run make all #To compile the dominion code
run ./playdom 30 # to run playdom code

For Assignment 4:

run make clean
run make randomtestadventurer
cat randomtestadventurer.out

run make clean
run make randomtestcard1
cat randomtestcard1.out

run make clean
run make randomtestcard2
cat randomtestcard2.out
